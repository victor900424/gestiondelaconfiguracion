package com.example.MyApiApplication;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MyApiApplicationTests {

	@Test
	void contextLoads() {
	}

}
